package com.example.pololetniprace;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.util.ArrayList;
import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private GameThread gameThread;
    private Player player;
    private ArrayList<Platform> platforms;
    private Random random = new Random();
    private static final int PLATFORM_COUNT = 10;
    private Context context; // Store reference to activity context

    public GameView(Context context) {
        super(context);
        this.context = context; // Store activity context
        getHolder().addCallback(this);
        gameThread = new GameThread(getHolder(), this);
        player = new Player(context, 300, 800);
        platforms = new ArrayList<>();
        initializePlatforms();
        //player.velocityY = -5;
    }
    public void updatePlayerMovement(float tiltX) {
        player.move(tiltX);
    }

    private void initializePlatforms() {
        for (int i = 0; i < PLATFORM_COUNT; i++) {
            platforms.add(new Platform(random.nextInt(1000), i * 200));
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        gameThread.setRunning(true);
        gameThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                gameThread.setRunning(false);
                gameThread.join();
                retry = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void update() {
        int screenHeight = getHeight();
        player.update();
        checkCollisions();

        // If player dies, goto mainmenu
        if (player.y + 100 >= screenHeight) {
            gameThread.setRunning(false); // Stop game loop
            HatMenu.setHatsUnlocked(0); // Save the new value
            //try {
            //    gameThread.join(); // Ensure the thread has stopped
            //} catch (InterruptedException e) {
            //    e.printStackTrace();
            //}
            Intent intent = new Intent(context, MainActivity.class);
            context.startActivity(intent);
            ((Activity) context).finish(); // Close the game activity
        }
        if (player.y <= 0) { // If player reaches the top of the screen
            // Get current hats unlocked from HatMenu
            int hatsUnlocked = HatMenu.getHatsUnlocked();
            hatsUnlocked++; // Increment
            HatMenu.setHatsUnlocked(hatsUnlocked); // Save the new value
            gameThread.setRunning(false); // Stop game loop
            //try {
            //    gameThread.join(); // Ensure the thread has stopped
            //} catch (InterruptedException e) {
            //    e.printStackTrace();
            //}
            Intent intent = new Intent(context, HatMenu.class);
            context.startActivity(intent);
            ((Activity) context).finish(); // Close the game activity
        }


    }

    private void goToGameOver() {

    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            canvas.drawColor(Color.WHITE);
            player.draw(canvas);
            for (Platform platform : platforms) {
                platform.draw(canvas);
            }
        }
    }

    private void checkCollisions() {
        for (Platform platform : platforms) {
            if (player.velocityY > 0 && platform.getBounds().intersects(player.x, player.y + 100, player.x + 50, player.y + 100)) {
                player.velocityY = -25;
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_MOVE:
                player.x = (int) event.getX() - 25;
                break;
        }
        return true;
    }
}
