package com.example.pololetniprace;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Platform {
    int x, y;

    public Platform(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.GREEN);
        canvas.drawRect(x, y, x + 200, y + 20, paint);
    }

    public RectF getBounds() {
        return new RectF(x, y, x + 200, y + 20);
    }
}
