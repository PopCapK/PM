package com.example.pololetniprace;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Player {
    int x, y;
    int velocityY = -20;
    private static final int GRAVITY = 1;
    private static final int SPEED = 10;
    public Bitmap hatBitmap; // Hat image
    public static int hatSelected = 0;



    public Player(Context context, int x, int y) {
        this.x = x;
        this.y = y;
        switch (hatSelected) {
            case 1: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h1);break;
            case 2: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h2);break;
            case 3: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h3);break;
            case 4: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h4);break;
            case 5: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h5);break;
            case 6: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h6);break;
            case 7: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h7);break;
            case 8: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h8);break;
            case 9: hatBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.h9);break;
        }
    }
    public void move(float tiltX) {
        // Move left if tiltX is positive (device tilts left)
        // Move right if tiltX is negative (device tilts right)
        x -= (int) (tiltX * SPEED);

        // Keep player inside screen boundaries
        if (x < 0) x = 0;
        if (x > 1000) x = 1000;  // Adjust width based on your screen size
    }


    public void update() {
        velocityY += GRAVITY;
        y += velocityY;
    }

    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.BLUE);
        canvas.drawRect(x, y, x + 50, y + 100, paint);
        if (hatBitmap != null) {
            int hatX = x - 10; // Adjust to center the hat
            int hatY = y - hatBitmap.getHeight(); // Position above the player
            canvas.drawBitmap(hatBitmap, hatX, hatY, null);
        }
    }
}
