package com.example.pololetniprace;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HatMenu extends AppCompatActivity {

    static int HatsUnlocked =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hat_menu);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            TextView hatsUnlockedText;
            hatsUnlockedText = findViewById(R.id.HatsUnlockedDisplay);

            hatsUnlockedText.setText("Hats Unlocked: " + HatsUnlocked);
            switch (HatsUnlocked) {
                case 0:
                    findViewById(R.id.hat1).setAlpha(0.25f);
                    findViewById(R.id.hat2).setAlpha(0.25f);
                    findViewById(R.id.hat3).setAlpha(0.25f);
                    findViewById(R.id.hat4).setAlpha(0.25f);
                    findViewById(R.id.hat5).setAlpha(0.25f);
                    findViewById(R.id.hat6).setAlpha(0.25f);
                    findViewById(R.id.hat7).setAlpha(0.25f);
                    findViewById(R.id.hat8).setAlpha(0.25f);
                    findViewById(R.id.hat9).setAlpha(0.25f);
                    Log.d("HatButtonOpacity", "case 0: ");
                    break;

                case 9: findViewById(R.id.hat9).setAlpha(1.0f);
                case 8: findViewById(R.id.hat8).setAlpha(1.0f);
                case 7: findViewById(R.id.hat7).setAlpha(1.0f);
                case 6: findViewById(R.id.hat6).setAlpha(1.0f);
                case 5: findViewById(R.id.hat5).setAlpha(1.0f);
                case 4: findViewById(R.id.hat4).setAlpha(1.0f);
                case 3: findViewById(R.id.hat3).setAlpha(1.0f);
                case 2: findViewById(R.id.hat2).setAlpha(1.0f);
                case 1: findViewById(R.id.hat1).setAlpha(1.0f);
            }
            return insets;
        });
    }
    //switch
    public void OnClick(View view) {

        switch (view.getId()) {
            case R.id.MainMenubtn:
                Intent intentDruhaAktivita = new Intent(HatMenu.this, MainActivity.class);
                startActivity(intentDruhaAktivita);
                break;


        }
    }
    public static int getHatsUnlocked() {
        return HatsUnlocked; // Default to 0 if not set
    }
    public static void setHatsUnlocked(int hatsUnlocked) {
        HatsUnlocked = hatsUnlocked;
        if (hatsUnlocked==0){Player.hatSelected = 0;}

    }
    public void changeHat(View view){

        switch (view.getId()) {
            case R.id.hat1:
                if(HatsUnlocked>=1) {
                    Player.hatSelected = 1;
                }
                break;
            case R.id.hat2:
                if(HatsUnlocked>=2) {
                    Player.hatSelected = 2;
                }
                break;
            case R.id.hat3:
                if(HatsUnlocked>=3) {
                    Player.hatSelected = 3;
                }
                break;
            case R.id.hat4:
                if(HatsUnlocked>=4) {
                    Player.hatSelected = 4;
                }
                break;
            case R.id.hat5:
                if(HatsUnlocked>=5) {
                    Player.hatSelected = 5;
                }
                break;
            case R.id.hat6:
                if(HatsUnlocked>=6) {
                    Player.hatSelected = 6;
                }
                break;
            case R.id.hat7:
                if(HatsUnlocked>=7) {
                    Player.hatSelected = 7;
                }
                break;
            case R.id.hat8:
                if(HatsUnlocked>=8) {
                    Player.hatSelected = 8;
                }
                break;
            case R.id.hat9:
                if(HatsUnlocked>=9) {
                    Player.hatSelected = 9;
                }
                break;

        }
    }

}